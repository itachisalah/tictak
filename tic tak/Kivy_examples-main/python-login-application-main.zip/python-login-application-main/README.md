# Registration Application

Code made in python using Kivy and KivyMD.

## Dependencies

kivy: v2.2.0.dev0

KivyMD: 1.1.1

```
pip install kivymd

pip install kivy[base] kivy_examples --pre --extra-index-url https://kivy.org/downloads/simple/.
```

## Usage
The general interface has been divided into two screens: Login and SignUp.

They will have their respective fields and checks.

when clicking on the access button, the respective data will be forwarded to a data.json file that accepts only one user.

## Final considerations
If you want to use the program for any of your projects, feel free.

Created by:
Matheus Marcelino Lopes
